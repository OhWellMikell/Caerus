Fantasy and Role-Play Game - Adventure Quest
============================================

Designer: Chanut is Industries (https://www.iconfinder.com/Chanut-is)License: Creative Commons (Attribution 3.0 Unported) (http://creativecommons.org/licenses/by/3.0/)